#include <algorithm>
#include <vector>
#include <cmath>
#include <cassert>
#include <cstdio>
void ExtendNativeClothRegion(std::vector<unsigned char>& pixels,int left,int top,int width,int height,int stride=512) {
    std::vector<int> columns(width,-1);
    for(int x=0;x<width;++x) {
        std::vector<int> rows;
        for(int y=0;y<height;++y)if(pixels[4*((top+y)*stride+left+x)+3]>=160)rows.push_back(y);
        if(rows.empty())continue;columns[x]=x;
        for(int y=0;y<height;++y) {
            auto* dst=pixels.data()+4*((top+y)*stride+left+x);
            if(dst[3]>=160)continue;
            int nearest=rows[0];for(auto row:rows)if(std::abs(row-y)<std::abs(nearest-y))nearest=row;
            std::copy_n(pixels.data()+4*((top+nearest)*stride+left+x),4,dst);dst[3]=255;
        }
    }
    for(int x=0;x<width;++x)if(columns[x]<0) {
        int nearest=-1;for(int i=0;i<width;++i)if(columns[i]>=0&&(nearest<0||std::abs(i-x)<std::abs(nearest-x)))nearest=i;
        if(nearest<0)continue;
        for(int y=0;y<height;++y)std::copy_n(pixels.data()+4*((top+y)*stride+left+nearest),4,pixels.data()+4*((top+y)*stride+left+x));
    }
}

int main() {
    for (int scale : {1,2}) {
        int stride=512*scale,left=256*scale,top=320*scale,width=256*scale,height=128*scale;
        std::vector<unsigned char> pixels(size_t(stride)*stride*4,7);
        size_t seed=4*(size_t(top+height/2)*stride+left+width/2);
        unsigned char color[]={21,80,143,255};
        std::copy_n(color,4,pixels.data()+seed);
        auto original=pixels;
        ExtendNativeClothRegion(pixels,left,top,width,height,stride);
        for(int y=0;y<stride;++y)for(int x=0;x<stride;++x) {
            bool inside=x>=left&&x<left+width&&y>=top&&y<top+height;
            for(int k=0;k<4;++k)assert(pixels[4*(size_t(y)*stride+x)+k]==(inside?color[k]:7));
        }
        if(scale==1) {
            ExtendNativeClothRegion(original,left,top,width,height);
            assert(original==pixels);
        }
    }
    std::puts("PASS actual cloth-extension code at 512 and 1024 pixels; outside regions and legacy default unchanged");
}
