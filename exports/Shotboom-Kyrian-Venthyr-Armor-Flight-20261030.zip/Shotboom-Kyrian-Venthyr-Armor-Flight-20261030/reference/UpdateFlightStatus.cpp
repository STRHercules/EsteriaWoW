void CGUnit_C::UpdateFlightStatus(uint32_t time) {
    if (this->m_kyrianTakeoffLiftState) this->UpdateKyrianTakeoffLift(OsGetAsyncTimeMs());
    uint32_t flags = this->m_movementData.m_flags;

    if (!(flags & 0x1000000)) {
        return;
    }

    if (!(flags & 0x2000000)) {
        if (!this->m_movementData.IsJumpingUp() && (this->m_movementData.m_flags & 0x1000) && this->IsActiveMover() && this->GetHeightAboveGround() >= 1.5f) {
            this->m_movementData.OnFlightLocal(time, 1);
            CGUnit_C::s_flightStatusTime = time;
        }

        return;
    }

    // STATIC: 0x00CA12B4
    static uint32_t s_nextFlightSoundTime = time + 2000;

    if (static_cast<int32_t>(time - s_nextFlightSoundTime) >= 0) {
        float bound;

        if (CMap::QueryFlightBounds(this->GetPosition(), &bound)) {
            float collisionHeight = this->m_movementData.m_collisionHeight;

            if (bound - 2.0f < this->GetPosition().z + collisionHeight) {
                // Native Kyrian wings should not play the stock bump/wound clip at the flight ceiling.
                if (!(this->IsActiveMover() && this->UsesNativeKyrianFlightModel())
                    && (!this->GetVehicleRec() || !this->m_vehicle->HasHighPriorityAnim())) {
                    this->PlayBaseAnimation(45, 0);
                    this->PlayWoundAnimKit(0);
                }

                CreatureSoundDataRec* sound = this->IsMounted() ? this->m_soundDataOverride : this->GetSoundData();

                if (sound) {
                    C3Vector position = this->GetPosition();

                    if (this->IsActivePlayer()) {
                        // STATIC: 0x00CA12B0
                        static CVar* s_listenerAtCharacter = CVar::Lookup("Sound_ListenerAtCharacter");

                        int32_t atCharacter = s_listenerAtCharacter->m_intValue;
                        SE2SoundKitProperties properties;
                        properties.ResetToDefaults();
                        properties.m_volumeScale = atCharacter ? 0.65f : 1.0f;
                        properties.m_priority = 110;
                        SI2::PlaySoundKit(sound->m_soundExertionID, atCharacter ? nullptr : &position, nullptr, &properties, 0, nullptr, 1, 0);
                    } else {
                        SI2::PlaySoundKit(sound->m_soundExertionID, &position, nullptr, nullptr, 0, nullptr, 1, 0);
                    }
                }

                s_nextFlightSoundTime = time + 2000;
            }
        }
    }

    if (!this->m_kyrianTakeoffLiftState && time - CGUnit_C::s_flightStatusTime > 2000 && this->m_obj->m_guid == CGUnit_C::s_activeMover && this->GetHeightAboveGround() < 1.5f && (!(this->m_obj->m_type & TYPEMASK_PLAYER) || !static_cast<CGPlayer_C*>(this)->IsCommentatorUberOrInArena())) {
        this->m_movementData.OnFlightLocal(time, 0);
    }
}
