# Kyrian / Venthyr armor clarity and Kyrian flight animation correction

Prepared for Shotboom, October 30, 2026. This is a small source integration handoff for the existing
Aetheria native-race framework. It contains no game archive, executable, database dump or credentials.

The armor patch is adapted to the published `Shotboom12/aetheria-client` revision
`6c06cde13cbe2bc17fc787f3ddb4a8521191b220` (`kyrian-venthyr-20261027-1`). That was still the public
main revision when this handoff was prepared. Source acknowledgements are retained in
`UPSTREAM-CREDITS.md` and `UPSTREAM-PROVENANCE.md`.

## 1. Sharper armor on both races

The old compositor first reduced equipment to a 512x512 atlas, then sampled it using integer fitting-map
coordinates. Enlarging that finished texture cannot recover the discarded detail.

The patch keeps the 512-pixel compatibility composition and also composes a 1024x1024 equipment atlas
directly from the source layers. It reconstructs the native body at twice its original width and height,
sampling the higher-resolution armor using interpolated fitting coordinates. Interpolation is limited
to continuous UV neighborhoods so it does not blend across separate body charts. Special glove,
coverage and shoe regions retain their existing fallback treatment. Robe/garment textures use the
higher-resolution atlas too, and the Venthyr greave-edge extension uses the correct scaled stride.

Both **Kyrian 60** and **Venthyr 61** use the new path. Other selector races keep their existing behavior.
The published compositor's BGRA-to-RGBA conversion is preserved exactly once before its BLP writer.
Existing fitting maps, palettes and model paths remain unchanged; no new textures, DBCs or SQL are
needed for this incremental correction.

Files:

- `patches/01-armor-resolution.patch` patches the public integration package's
  `integration/shared-dependencies/EsteriaSelectorOutfits.inl`.
- `patches/01-armor-resolution-full-client.patch` contains the same changes with the full-client path
  `WoW/Common/ComponentCore/EsteriaSelectorOutfits.inl`. Choose the appropriate armor patch once.
- `client/integration/shared-dependencies/EsteriaSelectorOutfits.inl` is the complete patched version
  of that published reference file, useful for comparison. Merge the patch if your shared file has
  diverged rather than replacing unrelated policies.

From the matching checkout, review first:

```text
git apply --check /path/to/01-armor-resolution.patch
git apply /path/to/01-armor-resolution.patch
```

Use the `-full-client` alternative in the actual full-client source tree, then rebuild using your normal
client procedure and fully restart the client. Keep your own race IDs; do not import Esteria's 75/76.

## 2. Stop the false wound/bump animation at Kyrian's flight ceiling

`patches/02-kyrian-flight-boundary.patch` changes `CGUnit_C::UpdateFlightStatus()` in
`WoW/Source/Object/ObjectClient/Unit_C.cpp` in the full client source tree.

The stock flight-ceiling branch plays animation 45 plus `PlayWoundAnimKit(0)`. When the native Kyrian
winged body reaches that bound, it looks like a damage/flinch animation. The correction suppresses
only that boundary-triggered pair for the active native Kyrian model. The physical height boundary,
normal damage reactions, other races, mounts and transformations keep their existing paths.

It reuses your existing `UsesNativeKyrianFlightModel()` helper from the published race integration.
No new class fields or header changes are needed. The existing takeoff/landing state machine and
`FinishKyrianTakeoff()` latch cleanup are already in your published patch and are not duplicated here.

```text
git apply --check /path/to/02-kyrian-flight-boundary.patch
git apply /path/to/02-kyrian-flight-boundary.patch
```

`reference/UpdateFlightStatus.cpp` contains the complete relevant function for manual merging. The
patch intentionally omits Esteria's temporary diagnostic logging. Its context was checked against
the recorded matching Esteria integration baseline; a full Aetheria checkout was not available here.

## Checks and acceptance

- The actual Esteria native client implementation was built and installed successfully.
- The user visually confirmed the male Venthyr armor result: "Looks great".
- The standalone pixel test checks the actual edge-extension helper at 512 and 1024 pixels, including
  unchanged pixels outside the target region and unchanged legacy default-stride behavior.
- Both armor patch paths and the flight patch were applied in isolated scratch inputs and compared
  with the supplied expected source. `PROVENANCE.json` records the reference hashes and scope.
- The Aetheria-adapted file has not been compiled inside Shotboom's complete client. Validate it there
  before deployment. There is no claim that every armor set or both genders have been visually accepted.

To run the small helper test from a Visual Studio developer prompt:

```text
cl /nologo /EHsc /std:c++17 /O2 tests\pixel_test.cpp /Fe:pixel_test.exe
pixel_test.exe
```

After merging, check both genders with chest armor, pants, robes, gloves and boots, including equipment
removal and the Venthyr cuff. Test takeoff, idle/forward/backward flight, the height ceiling, real damage,
descent and landing. Confirm ordinary mounts and other races retain their original ceiling reactions.

Rollback is the previous shared outfit source / Unit_C.cpp and the matching prior client executable.
