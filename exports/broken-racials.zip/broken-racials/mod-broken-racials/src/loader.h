void AddBrokenRacialsScripts();
